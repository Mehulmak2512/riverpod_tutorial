import 'package:flutter/material.dart';

import 'items.dart';

final List<Items> itemList = [

  Items(id: 1, name: "Red", color: Colors.red),
  Items(id: 2, name: "Green", color: Colors.green),
  Items(id: 3, name: "Blue", color: Colors.blue),
  Items(id: 4, name: "Yellow", color: Colors.yellow),
  Items(id: 5, name: "Pink", color: Colors.pink),
  Items(id: 6, name: "Purple", color: Colors.purple),
  Items(id: 7, name: "Orange", color: Colors.orange),
];