import 'package:flutter/material.dart';

class Items{
  final int id;
  final String name;
  final MaterialColor color;

  Items({required this.id, required this.name, required this.color});

}