// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'network.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$networkhandlerHash() => r'3febacd02149f2edbde701d6e553ec1f3d549967';

/// See also [networkhandler].
@ProviderFor(networkhandler)
final networkhandlerProvider = AutoDisposeProvider<NetworlHanler>.internal(
  networkhandler,
  name: r'networkhandlerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$networkhandlerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef NetworkhandlerRef = AutoDisposeProviderRef<NetworlHanler>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
