// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$productControllerHash() => r'e40ddb274218d043872f2248efbc05b54cf90caa';

/// See also [productController].
@ProviderFor(productController)
final productControllerProvider =
    AutoDisposeProvider<ProductController>.internal(
  productController,
  name: r'productControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$productControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef ProductControllerRef = AutoDisposeProviderRef<ProductController>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
