// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'riverpod.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$tradesHash() => r'4f4fc9247e4be3dc5941883925d9a2c703c11742';

/// See also [trades].
@ProviderFor(trades)
final tradesProvider = AutoDisposeNotifierProvider<trades, bool>.internal(
  trades.new,
  name: r'tradesProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$tradesHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$trades = AutoDisposeNotifier<bool>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
