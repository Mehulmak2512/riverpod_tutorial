// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'withdraw_request_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$withRequestHistoryListHash() =>
    r'10bc7e43b04a68fabc6c3ad87d81c534ed3342b3';

/// See also [WithRequestHistoryList].
@ProviderFor(WithRequestHistoryList)
final withRequestHistoryListProvider = AutoDisposeNotifierProvider<
    WithRequestHistoryList, List<WithdrawRequetHistoryDataUsers>>.internal(
  WithRequestHistoryList.new,
  name: r'withRequestHistoryListProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$withRequestHistoryListHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$WithRequestHistoryList
    = AutoDisposeNotifier<List<WithdrawRequetHistoryDataUsers>>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
