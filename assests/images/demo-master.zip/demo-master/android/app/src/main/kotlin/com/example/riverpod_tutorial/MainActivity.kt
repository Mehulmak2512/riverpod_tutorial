package com.example.riverpod_tutorial

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
