import 'dart:developer';

import 'package:country_picker/country_picker.dart';
import 'package:ecommerce_app/common/custom_appbar_background.dart';
import 'package:ecommerce_app/constants/constant_colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter_hooks/flutter_hooks.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:hooks_riverpod/hooks_riverpod.dart';

class Practice extends HookConsumerWidget {
  const Practice({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {

    final controller = useTextEditingController();
    final focusNode = useFocusNode();
    final selectedCountry = useState("91");
    final phoneLength = useState(10);

    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Practice",
          style: GoogleFonts.spaceGrotesk(color: Colors.white),
        ),
        centerTitle: true,
        flexibleSpace: const CustomAppBarBackground(),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 18.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              TextFormField(
                controller: controller,
                focusNode: focusNode,
                autovalidateMode: AutovalidateMode.always,
                keyboardType: TextInputType.number,
                validator: (value) {
                  if (value!.isEmpty) {
                    return "Please enter the Mobile no.";
                  }else if(value.length != phoneLength.value){
                    return "Please enter the valid Mobile no.";
                  }
                  return null;
                },
                style: GoogleFonts.spaceGrotesk(color: ConstantColors.black, fontWeight: FontWeight.bold),
                // obscureText: isObsureText.value,
                decoration: InputDecoration(
                  label: Text(
                    "Mobile No.",
                    style: GoogleFonts.spaceGrotesk(color: ConstantColors.grey, fontWeight: FontWeight.bold),
                  ),
                  contentPadding: const EdgeInsets.all(8),
                  prefixIcon: Padding(
                    padding: const EdgeInsets.all(15),
                    child: GestureDetector(
                        onTap: () {
                          showCountryPicker(
                            context: context,
                            showPhoneCode: true,
                            useSafeArea: true ,
                            countryListTheme: CountryListThemeData(
                              margin: const EdgeInsets.symmetric(horizontal: 10),
                              borderRadius: BorderRadius.circular(10),
                              flagSize: 25.0,
                              bottomSheetHeight: 600,
                              inputDecoration: InputDecoration(
                                contentPadding: const EdgeInsets.all(8),
                                hintText: "Search",
                                hintStyle: GoogleFonts.spaceGrotesk(fontSize: 18),
                                prefixIcon: const Icon(Icons.search,),
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(15)
                                )
                              )

                            ),
                            onSelect: (Country country) {
                              log("selected country --> ${country.phoneCode} and ${country.example.length}");
                               selectedCountry.value = country.phoneCode;
                               phoneLength.value = country.example.length;
                            },
                          );
                        },
                        child: Text(
                          "+${selectedCountry.value}",
                          style: GoogleFonts.spaceGrotesk(color: ConstantColors.black, fontWeight: FontWeight.bold, fontSize: 16),
                          textAlign: TextAlign.center,
                        )),
                  ),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: const BorderSide(color: ConstantColors.grey)),
                  focusedBorder:
                      OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: const BorderSide(color: ConstantColors.pinkAccent)),
                  errorBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: const BorderSide(color: ConstantColors.red)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
