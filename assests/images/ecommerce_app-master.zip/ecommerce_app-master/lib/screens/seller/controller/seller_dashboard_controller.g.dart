// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'seller_dashboard_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$sellerDashBoardControllerHash() =>
    r'e47046ae9cd0cc71d15333fdfb3919bb5154c621';

/// See also [SellerDashBoardController].
@ProviderFor(SellerDashBoardController)
final sellerDashBoardControllerProvider = AutoDisposeAsyncNotifierProvider<
    SellerDashBoardController, List<Map<String, dynamic>>>.internal(
  SellerDashBoardController.new,
  name: r'sellerDashBoardControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$sellerDashBoardControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$SellerDashBoardController
    = AutoDisposeAsyncNotifier<List<Map<String, dynamic>>>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
