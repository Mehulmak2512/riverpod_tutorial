// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'user_dashboard_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$userDashboardControllerHash() =>
    r'89d9f669054698e89f1ce11ca96ff70c3c70cb93';

/// See also [UserDashboardController].
@ProviderFor(UserDashboardController)
final userDashboardControllerProvider = AutoDisposeAsyncNotifierProvider<
    UserDashboardController, List<Map<String, dynamic>>>.internal(
  UserDashboardController.new,
  name: r'userDashboardControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$userDashboardControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$UserDashboardController
    = AutoDisposeAsyncNotifier<List<Map<String, dynamic>>>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
