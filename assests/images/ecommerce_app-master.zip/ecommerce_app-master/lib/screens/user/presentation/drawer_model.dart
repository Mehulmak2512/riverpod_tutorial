import 'package:flutter/cupertino.dart';

class DrawerList{
  final String text;
  final IconData iconData;

  DrawerList({required this.text, required this.iconData});
}