String uId = "";
bool isUser = false;
bool isSeller = false;