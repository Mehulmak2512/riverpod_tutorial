// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'seller_auth.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$sellerAuthHash() => r'97d1e08d28c9a11e1bb725d46510c13aa738eb41';

/// See also [SellerAuth].
@ProviderFor(SellerAuth)
final sellerAuthProvider =
    AutoDisposeAsyncNotifierProvider<SellerAuth, void>.internal(
  SellerAuth.new,
  name: r'sellerAuthProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$sellerAuthHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$SellerAuth = AutoDisposeAsyncNotifier<void>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
